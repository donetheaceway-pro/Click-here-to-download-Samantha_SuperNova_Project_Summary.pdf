/* ============================
   DRAGGABLE BOXES
============================ */
document.querySelectorAll('.box').forEach(box => {
    box.addEventListener('mousedown', startDrag);

    function startDrag(e) {
        e.preventDefault();

        let shiftX = e.clientX - box.getBoundingClientRect().left;
        let shiftY = e.clientY - box.getBoundingClientRect().top;

        document.addEventListener('mousemove', moveBox);
        document.addEventListener('mouseup', stopDrag);

        function moveBox(e) {
            box.style.position = "absolute";
            box.style.left = e.pageX - shiftX + "px";
            box.style.top = e.pageY - shiftY + "px";
            box.style.zIndex = 9999;
        }

        function stopDrag() {
            document.removeEventListener('mousemove', moveBox);
            document.removeEventListener('mouseup', stopDrag);
        }
    }
});

/* ============================
   NOVA ORB — OPEN SLIDE PANEL
============================ */
const novaOrb = document.querySelector('.nova-orb');
const novaPanel = document.querySelector('.nova-panel');

if (novaOrb && novaPanel) {
    novaOrb.addEventListener('click', () => {
        novaPanel.classList.toggle('open');
    });
}

/* ============================
   NOVA BUTTON INSIDE PANEL
============================ */
const novaAction = document.querySelector('#nova-action');

if (novaAction) {
    novaAction.addEventListener('click', () => {
        alert("Nova received your approval ✓");
        // This is where automation triggers go later
    });
}

/* ============================
   SMOOTH SCROLL FIX FOR DASH
============================ */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute("href"));
        if (target) {
            target.scrollIntoView({ behavior: "smooth" });
        }
    });
});
