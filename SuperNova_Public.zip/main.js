/* ============================================================
   NOVA ORB — PANEL TOGGLE
============================================================ */
const novaOrb = document.getElementById("novaOrb");
const novaPanel = document.getElementById("novaPanel");

if (novaOrb && novaPanel) {
  novaOrb.addEventListener("click", () => {
    novaPanel.classList.toggle("collapsed");
  });
}

/* ============================================================
   AUTOMATION BRANCH SYSTEM
============================================================ */
const branches = ["dashboard", "webpages", "exams", "builders", "addons"];
let currentIndex = 0;

const currentBranchLabel = document.getElementById("currentBranchLabel");
const nextBranchLabel = document.getElementById("nextBranchLabel");
const panelCurrentBranch = document.getElementById("panelCurrentBranch");
const panelNextBranch = document.getElementById("panelNextBranch");
const branchButtons = document.querySelectorAll(".branchBtn");

function updateBranchDisplay() {
  const current = branches[currentIndex];
  currentBranchLabel.textContent = capitalize(current);
  panelCurrentBranch.textContent = capitalize(current);

  const next = branches[currentIndex + 1] || "Complete";
  nextBranchLabel.textContent = capitalize(next);
  panelNextBranch.textContent = capitalize(next);

  branchButtons.forEach((btn, i) => {
    const dot = btn.querySelector(".dot");
    const text = btn.querySelector(".statusText");

    btn.classList.remove("active");

    if (i === currentIndex) {
      btn.classList.add("active");
      dot.className = "dot pending";
      text.textContent = "Pending";
    } else if (i < currentIndex) {
      dot.className = "dot done";
      text.textContent = "Complete";
    } else {
      dot.className = "dot locked";
      text.textContent = "Locked";
    }
  });
}

function capitalize(word) {
  return word.charAt(0).toUpperCase() + word.slice(1);
}

updateBranchDisplay();

/* ============================================================
   UNLOCK NEXT BRANCH
============================================================ */
document.getElementById("nextBranchBtn")
  .addEventListener("click", () => {
    if (currentIndex < branches.length - 1) {
      currentIndex++;
      updateBranchDisplay();
      addCompletedLog("Completed " + capitalize(branches[currentIndex - 1]));
    } else {
      addCompletedLog("All branches complete");
      alert("🎉 All tasks completed!");
    }
  });

/* ============================================================
   RUN CURRENT BRANCH
============================================================ */
document.getElementById("runBranchBtn")
  .addEventListener("click", () => {
    const currentBranch = branches[currentIndex];
    addUpcomingLog("Running " + capitalize(currentBranch) + " branch...");
    simulateProgress();
  });

/* ============================================================
   COMPLETE THIS TASK (NOVA)
============================================================ */
document.getElementById("completeTaskNovaBtn")
  .addEventListener("click", () => {
    const currentBranch = branches[currentIndex];
    addCompletedLog("Nova completed: " + capitalize(currentBranch));
    simulateProgress(true);
  });

/* ============================================================
   PROGRESS BAR
============================================================ */
const progressFill = document.getElementById("progressFill");
const progressPercent = document.getElementById("progressPercent");

function simulateProgress(autoAdvance = false) {
  let width = 0;

  const interval = setInterval(() => {
    width += 2;
    progressFill.style.width = width + "%";
    progressPercent.textContent = width + "%";

    if (width >= 100) {
      clearInterval(interval);

      if (autoAdvance && currentIndex < branches.length - 1) {
        currentIndex++;
        updateBranchDisplay();
        addCompletedLog("Auto-unlocked: " + capitalize(branches[currentIndex]));
      }
    }
  }, 50);
}

/* ============================================================
   NOVA PANEL LOGS
============================================================ */
const completedList = document.getElementById("novaCompletedList");
const upcomingList = document.getElementById("novaUpcomingList");

function addCompletedLog(text) {
  const li = document.createElement("li");
  li.textContent = "✔ " + text;
  completedList.appendChild(li);
}

function addUpcomingLog(text) {
  const li = document.createElement("li");
  li.textContent = "• " + text;
  upcomingList.appendChild(li);
}

/* ============================================================
   SURPRISE ME BUTTON
============================================================ */
document.getElementById("surpriseLayoutBtn")
  .addEventListener("click", () => {
    const colors = ["#FF33FF", "#33CCFF", "#99FF33", "#FFCC33", "#FF4444"];
    document.body.style.backgroundColor =
      colors[Math.floor(Math.random() * colors.length)];
  });

/* ============================================================
   NOVA CHAT SYSTEM
============================================================ */
const chatMessages = document.getElementById("chatMessages");
const chatInput = document.getElementById("chatInput");
const chatSendBtn = document.getElementById("chatSendBtn");

function addChatMessage(text, sender) {
  const div = document.createElement("div");
  div.className = "chatMsg " + sender;
  div.textContent = text;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

chatSendBtn.addEventListener("click", () => {
  const msg = chatInput.value.trim();
  if (!msg) return;

  addChatMessage(msg, "user");
  chatInput.value = "";

  setTimeout(() => {
    addChatMessage("Nova received: " + msg, "nova");
  }, 300);
});
